#!/bin/bash -p
echo -e "Creating TAP device tap346_0\n"
command -v tunctl > /dev/null || (echo "Missing tunctl ... check your installation - install uml-utilities package" && exit 1)
tunctl -t tap346_0
echo -e "Bringing up HOSTNETDEV \033[0;33mtap346_0.0\033[0m / VLAN ID \033[0;33m0\033[0m / TAPDEV \033[0;33mtap346_0\033[0m.\n"
ip link add link tap346_0 name tap346_0.0 type vlan id 0
ip link set tap346_0 up
echo -e "Bringing up HOSTIP \033[0;33m192.168.0.2\033[0m / IP address \033[0;33m192.168.0.1\033[0m / TAPDEV \033[0;33mtap346_0\033[0m.\n"
ip link set tap346_0.0 up
ip addr add 192.168.0.2/8 dev tap346_0.0
ifconfig -a
route -n
echo -e "[*] Starting firmware emulation \033[0;33mqemu-system-mipsel / mipsel / 1179788-3612812.squashfs_v4_le_extract_mipsel-23098 / 192.168.0.1\033[0m ... use Ctrl-a + x to exit\n"
echo -e "[*] For emulation state please monitor the \033[0;33mqemu.serial.log\033[0m file\n"
echo -e "[*] For shell access check localhost port \033[0;33m4321\033[0m via telnet\n"
qemu-system-mipsel -m 2048 -M malta  -kernel ./vmlinux.mipsel.4 -drive if=ide,format=raw,file=./1179788-3612812.squashfs_v4_le_extract_mipsel-23098 -append "root=/dev/sda1 console=ttyS0 nandsim.parts=64,64,64,64,64,64,64,64,64,64 init=/etc/init.d/rcS rw debug ignore_loglevel print-fatal-signals=1 EMBA_NET=true EMBA_NVRAM=true EMBA_KERNEL=true EMBA_ETC=true user_debug=0 firmadyne.syscall=1" -nographic  -device e1000,netdev=net0 -netdev socket,id=net0,listen=:2000 -device e1000,netdev=net1 -netdev socket,id=net1,listen=:2001 -device e1000,netdev=net2 -netdev tap,id=net2,ifname=tap346_0,script=no -device e1000,netdev=net3 -netdev socket,id=net3,listen=:2003  -serial file:./qemu.serial.log -serial telnet:localhost:4321,server,nowait -serial unix:/tmp/qemu.1179788-3612812.squashfs_v4_le_extract_mipsel-23098.S1,server,nowait -monitor unix:/tmp/qemu.1179788-3612812.squashfs_v4_le_extract_mipsel-23098,server,nowait
echo -e "Deleting route ...\n"
ip route flush dev tap346_0.0
echo -e "Bringing down TAP device ...\n"
ip link set tap346_0 down
echo -e "Removing VLAN ...\n"
ip link delete tap346_0.0
echo -e "Deleting TAP device ...\n"
tunctl -d tap346_0
